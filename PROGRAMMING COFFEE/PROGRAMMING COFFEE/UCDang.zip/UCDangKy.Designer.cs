﻿namespace PROGRAMMING_COFFEE
{
    partial class UCDangKy
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(UCDangKy));
            this.n_txtPass = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.bunifuCustomLabel4 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.n_txtUser = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.bunifuCustomLabel3 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.n_ButtonDangKi = new Bunifu.Framework.UI.BunifuThinButton2();
            this.n_txtAgain = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.bunifuCustomLabel1 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.n_txtPhone = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.bunifuCustomLabel6 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.bunifuCustomLabel5 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.checkMale = new Bunifu.Framework.UI.BunifuCheckbox();
            this.checkFemale = new Bunifu.Framework.UI.BunifuCheckbox();
            this.bunifuCustomLabel7 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.bunifuCustomLabel8 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.errorProvider1 = new System.Windows.Forms.ErrorProvider(this.components);
            this.errorProvider2 = new System.Windows.Forms.ErrorProvider(this.components);
            this.errorProvider3 = new System.Windows.Forms.ErrorProvider(this.components);
            this.errorProvider4 = new System.Windows.Forms.ErrorProvider(this.components);
            this.n_Status = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.bunifuCustomLabel9 = new Bunifu.Framework.UI.BunifuCustomLabel();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider4)).BeginInit();
            this.SuspendLayout();
            // 
            // n_txtPass
            // 
            this.n_txtPass.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.n_txtPass.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.n_txtPass.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(182)))), ((int)(((byte)(245)))));
            this.n_txtPass.HintForeColor = System.Drawing.Color.Empty;
            this.n_txtPass.HintText = "";
            this.n_txtPass.isPassword = true;
            this.n_txtPass.LineFocusedColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(182)))), ((int)(((byte)(245)))));
            this.n_txtPass.LineIdleColor = System.Drawing.Color.Gray;
            this.n_txtPass.LineMouseHoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(182)))), ((int)(((byte)(245)))));
            this.n_txtPass.LineThickness = 4;
            this.n_txtPass.Location = new System.Drawing.Point(371, 195);
            this.n_txtPass.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.n_txtPass.Name = "n_txtPass";
            this.n_txtPass.Size = new System.Drawing.Size(388, 34);
            this.n_txtPass.TabIndex = 22;
            this.n_txtPass.Text = "1234";
            this.n_txtPass.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // bunifuCustomLabel4
            // 
            this.bunifuCustomLabel4.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.bunifuCustomLabel4.AutoSize = true;
            this.bunifuCustomLabel4.Font = new System.Drawing.Font("Segoe UI Light", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel4.Location = new System.Drawing.Point(159, 204);
            this.bunifuCustomLabel4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.bunifuCustomLabel4.Name = "bunifuCustomLabel4";
            this.bunifuCustomLabel4.Size = new System.Drawing.Size(89, 25);
            this.bunifuCustomLabel4.TabIndex = 90;
            this.bunifuCustomLabel4.Text = "Mật khẩu:";
            // 
            // n_txtUser
            // 
            this.n_txtUser.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.n_txtUser.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.n_txtUser.Font = new System.Drawing.Font("Segoe UI Light", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.n_txtUser.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(182)))), ((int)(((byte)(245)))));
            this.n_txtUser.HintForeColor = System.Drawing.Color.Empty;
            this.n_txtUser.HintText = "";
            this.n_txtUser.isPassword = false;
            this.n_txtUser.LineFocusedColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(182)))), ((int)(((byte)(245)))));
            this.n_txtUser.LineIdleColor = System.Drawing.Color.Gray;
            this.n_txtUser.LineMouseHoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(182)))), ((int)(((byte)(245)))));
            this.n_txtUser.LineThickness = 4;
            this.n_txtUser.Location = new System.Drawing.Point(371, 134);
            this.n_txtUser.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.n_txtUser.Name = "n_txtUser";
            this.n_txtUser.Size = new System.Drawing.Size(388, 34);
            this.n_txtUser.TabIndex = 21;
            this.n_txtUser.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // bunifuCustomLabel3
            // 
            this.bunifuCustomLabel3.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.bunifuCustomLabel3.AutoSize = true;
            this.bunifuCustomLabel3.Font = new System.Drawing.Font("Segoe UI Light", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel3.Location = new System.Drawing.Point(159, 143);
            this.bunifuCustomLabel3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.bunifuCustomLabel3.Name = "bunifuCustomLabel3";
            this.bunifuCustomLabel3.Size = new System.Drawing.Size(134, 25);
            this.bunifuCustomLabel3.TabIndex = 20;
            this.bunifuCustomLabel3.Text = "Tên đăng nhập:";
            // 
            // n_ButtonDangKi
            // 
            this.n_ButtonDangKi.ActiveBorderThickness = 1;
            this.n_ButtonDangKi.ActiveCornerRadius = 20;
            this.n_ButtonDangKi.ActiveFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(182)))), ((int)(((byte)(245)))));
            this.n_ButtonDangKi.ActiveForecolor = System.Drawing.Color.White;
            this.n_ButtonDangKi.ActiveLineColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(182)))), ((int)(((byte)(245)))));
            this.n_ButtonDangKi.BackColor = System.Drawing.Color.White;
            this.n_ButtonDangKi.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("n_ButtonDangKi.BackgroundImage")));
            this.n_ButtonDangKi.ButtonText = "Đăng kí";
            this.n_ButtonDangKi.Cursor = System.Windows.Forms.Cursors.Hand;
            this.n_ButtonDangKi.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.n_ButtonDangKi.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(182)))), ((int)(((byte)(245)))));
            this.n_ButtonDangKi.IdleBorderThickness = 1;
            this.n_ButtonDangKi.IdleCornerRadius = 20;
            this.n_ButtonDangKi.IdleFillColor = System.Drawing.Color.White;
            this.n_ButtonDangKi.IdleForecolor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(182)))), ((int)(((byte)(245)))));
            this.n_ButtonDangKi.IdleLineColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(182)))), ((int)(((byte)(245)))));
            this.n_ButtonDangKi.Location = new System.Drawing.Point(594, 433);
            this.n_ButtonDangKi.Margin = new System.Windows.Forms.Padding(5);
            this.n_ButtonDangKi.Name = "n_ButtonDangKi";
            this.n_ButtonDangKi.Size = new System.Drawing.Size(165, 45);
            this.n_ButtonDangKi.TabIndex = 27;
            this.n_ButtonDangKi.Tag = "";
            this.n_ButtonDangKi.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.n_ButtonDangKi.Click += new System.EventHandler(this.n_ButtonDangKi_Click);
            // 
            // n_txtAgain
            // 
            this.n_txtAgain.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.n_txtAgain.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.n_txtAgain.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(182)))), ((int)(((byte)(245)))));
            this.n_txtAgain.HintForeColor = System.Drawing.Color.Empty;
            this.n_txtAgain.HintText = "";
            this.n_txtAgain.isPassword = true;
            this.n_txtAgain.LineFocusedColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(182)))), ((int)(((byte)(245)))));
            this.n_txtAgain.LineIdleColor = System.Drawing.Color.Gray;
            this.n_txtAgain.LineMouseHoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(182)))), ((int)(((byte)(245)))));
            this.n_txtAgain.LineThickness = 4;
            this.n_txtAgain.Location = new System.Drawing.Point(371, 257);
            this.n_txtAgain.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.n_txtAgain.Name = "n_txtAgain";
            this.n_txtAgain.Size = new System.Drawing.Size(388, 34);
            this.n_txtAgain.TabIndex = 23;
            this.n_txtAgain.Text = "1234";
            this.n_txtAgain.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // bunifuCustomLabel1
            // 
            this.bunifuCustomLabel1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.bunifuCustomLabel1.AutoSize = true;
            this.bunifuCustomLabel1.Font = new System.Drawing.Font("Segoe UI Light", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel1.Location = new System.Drawing.Point(159, 266);
            this.bunifuCustomLabel1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.bunifuCustomLabel1.Name = "bunifuCustomLabel1";
            this.bunifuCustomLabel1.Size = new System.Drawing.Size(159, 25);
            this.bunifuCustomLabel1.TabIndex = 29;
            this.bunifuCustomLabel1.Text = "Nhập lại mật khẩu:";
            // 
            // n_txtPhone
            // 
            this.n_txtPhone.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.n_txtPhone.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.n_txtPhone.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.n_txtPhone.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(182)))), ((int)(((byte)(245)))));
            this.n_txtPhone.HintForeColor = System.Drawing.Color.Empty;
            this.n_txtPhone.HintText = "";
            this.n_txtPhone.isPassword = false;
            this.n_txtPhone.LineFocusedColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(182)))), ((int)(((byte)(245)))));
            this.n_txtPhone.LineIdleColor = System.Drawing.Color.Gray;
            this.n_txtPhone.LineMouseHoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(182)))), ((int)(((byte)(245)))));
            this.n_txtPhone.LineThickness = 4;
            this.n_txtPhone.Location = new System.Drawing.Point(371, 372);
            this.n_txtPhone.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.n_txtPhone.Name = "n_txtPhone";
            this.n_txtPhone.Size = new System.Drawing.Size(388, 34);
            this.n_txtPhone.TabIndex = 26;
            this.n_txtPhone.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // bunifuCustomLabel6
            // 
            this.bunifuCustomLabel6.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.bunifuCustomLabel6.AutoSize = true;
            this.bunifuCustomLabel6.Font = new System.Drawing.Font("Segoe UI Light", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel6.Location = new System.Drawing.Point(162, 381);
            this.bunifuCustomLabel6.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.bunifuCustomLabel6.Name = "bunifuCustomLabel6";
            this.bunifuCustomLabel6.Size = new System.Drawing.Size(98, 25);
            this.bunifuCustomLabel6.TabIndex = 31;
            this.bunifuCustomLabel6.Text = "Điện thoại:";
            // 
            // bunifuCustomLabel5
            // 
            this.bunifuCustomLabel5.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.bunifuCustomLabel5.AutoSize = true;
            this.bunifuCustomLabel5.Font = new System.Drawing.Font("Segoe UI Light", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel5.Location = new System.Drawing.Point(162, 324);
            this.bunifuCustomLabel5.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.bunifuCustomLabel5.Name = "bunifuCustomLabel5";
            this.bunifuCustomLabel5.Size = new System.Drawing.Size(88, 25);
            this.bunifuCustomLabel5.TabIndex = 36;
            this.bunifuCustomLabel5.Text = "Giới tính :";
            // 
            // checkMale
            // 
            this.checkMale.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(205)))), ((int)(((byte)(117)))));
            this.checkMale.ChechedOffColor = System.Drawing.Color.FromArgb(((int)(((byte)(132)))), ((int)(((byte)(135)))), ((int)(((byte)(140)))));
            this.checkMale.Checked = true;
            this.checkMale.CheckedOnColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(205)))), ((int)(((byte)(117)))));
            this.checkMale.ForeColor = System.Drawing.Color.White;
            this.checkMale.Location = new System.Drawing.Point(383, 329);
            this.checkMale.Name = "checkMale";
            this.checkMale.Size = new System.Drawing.Size(20, 20);
            this.checkMale.TabIndex = 24;
            this.checkMale.OnChange += new System.EventHandler(this.checkMale_OnChange);
            // 
            // checkFemale
            // 
            this.checkFemale.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(132)))), ((int)(((byte)(135)))), ((int)(((byte)(140)))));
            this.checkFemale.ChechedOffColor = System.Drawing.Color.FromArgb(((int)(((byte)(132)))), ((int)(((byte)(135)))), ((int)(((byte)(140)))));
            this.checkFemale.Checked = false;
            this.checkFemale.CheckedOnColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(205)))), ((int)(((byte)(117)))));
            this.checkFemale.ForeColor = System.Drawing.Color.White;
            this.checkFemale.Location = new System.Drawing.Point(628, 324);
            this.checkFemale.Name = "checkFemale";
            this.checkFemale.Size = new System.Drawing.Size(20, 20);
            this.checkFemale.TabIndex = 25;
            this.checkFemale.OnChange += new System.EventHandler(this.checkFemale_OnChange);
            // 
            // bunifuCustomLabel7
            // 
            this.bunifuCustomLabel7.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.bunifuCustomLabel7.AutoSize = true;
            this.bunifuCustomLabel7.Font = new System.Drawing.Font("Segoe UI Light", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel7.Location = new System.Drawing.Point(408, 324);
            this.bunifuCustomLabel7.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.bunifuCustomLabel7.Name = "bunifuCustomLabel7";
            this.bunifuCustomLabel7.Size = new System.Drawing.Size(50, 25);
            this.bunifuCustomLabel7.TabIndex = 38;
            this.bunifuCustomLabel7.Text = "Nam";
            // 
            // bunifuCustomLabel8
            // 
            this.bunifuCustomLabel8.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.bunifuCustomLabel8.AutoSize = true;
            this.bunifuCustomLabel8.Font = new System.Drawing.Font("Segoe UI Light", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel8.Location = new System.Drawing.Point(653, 319);
            this.bunifuCustomLabel8.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.bunifuCustomLabel8.Name = "bunifuCustomLabel8";
            this.bunifuCustomLabel8.Size = new System.Drawing.Size(35, 25);
            this.bunifuCustomLabel8.TabIndex = 39;
            this.bunifuCustomLabel8.Text = "Nữ";
            // 
            // errorProvider1
            // 
            this.errorProvider1.ContainerControl = this;
            // 
            // errorProvider2
            // 
            this.errorProvider2.ContainerControl = this;
            // 
            // errorProvider3
            // 
            this.errorProvider3.ContainerControl = this;
            // 
            // errorProvider4
            // 
            this.errorProvider4.ContainerControl = this;
            // 
            // n_Status
            // 
            this.n_Status.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.n_Status.AutoSize = true;
            this.n_Status.Font = new System.Drawing.Font("Segoe UI Light", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.n_Status.Location = new System.Drawing.Point(285, 96);
            this.n_Status.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.n_Status.Name = "n_Status";
            this.n_Status.Size = new System.Drawing.Size(0, 25);
            this.n_Status.TabIndex = 41;
            // 
            // bunifuCustomLabel9
            // 
            this.bunifuCustomLabel9.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.bunifuCustomLabel9.AutoSize = true;
            this.bunifuCustomLabel9.BackColor = System.Drawing.Color.White;
            this.bunifuCustomLabel9.Font = new System.Drawing.Font("Segoe UI", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel9.ForeColor = System.Drawing.Color.MediumBlue;
            this.bunifuCustomLabel9.Location = new System.Drawing.Point(296, 52);
            this.bunifuCustomLabel9.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.bunifuCustomLabel9.Name = "bunifuCustomLabel9";
            this.bunifuCustomLabel9.Size = new System.Drawing.Size(296, 37);
            this.bunifuCustomLabel9.TabIndex = 91;
            this.bunifuCustomLabel9.Text = "Đăng ký làm thành viên";
            // 
            // UCDangKy
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.Controls.Add(this.bunifuCustomLabel9);
            this.Controls.Add(this.n_Status);
            this.Controls.Add(this.bunifuCustomLabel8);
            this.Controls.Add(this.bunifuCustomLabel7);
            this.Controls.Add(this.checkFemale);
            this.Controls.Add(this.bunifuCustomLabel5);
            this.Controls.Add(this.checkMale);
            this.Controls.Add(this.n_txtPhone);
            this.Controls.Add(this.bunifuCustomLabel6);
            this.Controls.Add(this.n_txtAgain);
            this.Controls.Add(this.bunifuCustomLabel1);
            this.Controls.Add(this.n_ButtonDangKi);
            this.Controls.Add(this.n_txtPass);
            this.Controls.Add(this.bunifuCustomLabel4);
            this.Controls.Add(this.n_txtUser);
            this.Controls.Add(this.bunifuCustomLabel3);
            this.Name = "UCDangKy";
            this.Size = new System.Drawing.Size(869, 503);
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider4)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private Bunifu.Framework.UI.BunifuThinButton2 n_ButtonDangKi;
        private Bunifu.Framework.UI.BunifuMaterialTextbox n_txtPass;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel4;
        private Bunifu.Framework.UI.BunifuMaterialTextbox n_txtUser;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel3;
        private Bunifu.Framework.UI.BunifuMaterialTextbox n_txtAgain;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel1;
        private Bunifu.Framework.UI.BunifuMaterialTextbox n_txtPhone;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel6;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel5;
        private Bunifu.Framework.UI.BunifuCheckbox checkMale;
        private Bunifu.Framework.UI.BunifuCheckbox checkFemale;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel7;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel8;
        private System.Windows.Forms.ErrorProvider errorProvider1;
        private System.Windows.Forms.ErrorProvider errorProvider2;
        private System.Windows.Forms.ErrorProvider errorProvider3;
        private System.Windows.Forms.ErrorProvider errorProvider4;
        private Bunifu.Framework.UI.BunifuCustomLabel n_Status;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel9;
    }
}
