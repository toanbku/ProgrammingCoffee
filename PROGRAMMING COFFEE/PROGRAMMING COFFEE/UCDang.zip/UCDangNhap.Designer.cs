﻿namespace PROGRAMMING_COFFEE
{
    partial class UCDangNhap
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(UCDangNhap));
            this.bunifuCustomLabel2 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.n_TextboxMauKhauDangNhap = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.bunifuCustomLabel4 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.n_TextboxTenDangNhap = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.bunifuCustomLabel3 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.bunifuCustomLabel5 = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.n_ButtonDangKi = new Bunifu.Framework.UI.BunifuThinButton2();
            this.n_ButtonDangNhap = new Bunifu.Framework.UI.BunifuThinButton2();
            this.n_Status = new Bunifu.Framework.UI.BunifuCustomLabel();
            this.SuspendLayout();
            // 
            // bunifuCustomLabel2
            // 
            this.bunifuCustomLabel2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.bunifuCustomLabel2.AutoSize = true;
            this.bunifuCustomLabel2.BackColor = System.Drawing.Color.White;
            this.bunifuCustomLabel2.Font = new System.Drawing.Font("Segoe UI", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel2.ForeColor = System.Drawing.Color.MediumBlue;
            this.bunifuCustomLabel2.Location = new System.Drawing.Point(257, 43);
            this.bunifuCustomLabel2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.bunifuCustomLabel2.Name = "bunifuCustomLabel2";
            this.bunifuCustomLabel2.Size = new System.Drawing.Size(246, 37);
            this.bunifuCustomLabel2.TabIndex = 2;
            this.bunifuCustomLabel2.Text = "Tiếp tục đăng nhập";
            // 
            // n_TextboxMauKhauDangNhap
            // 
            this.n_TextboxMauKhauDangNhap.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.n_TextboxMauKhauDangNhap.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.n_TextboxMauKhauDangNhap.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(182)))), ((int)(((byte)(245)))));
            this.n_TextboxMauKhauDangNhap.HintForeColor = System.Drawing.Color.Empty;
            this.n_TextboxMauKhauDangNhap.HintText = "";
            this.n_TextboxMauKhauDangNhap.isPassword = true;
            this.n_TextboxMauKhauDangNhap.LineFocusedColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(182)))), ((int)(((byte)(245)))));
            this.n_TextboxMauKhauDangNhap.LineIdleColor = System.Drawing.Color.Gray;
            this.n_TextboxMauKhauDangNhap.LineMouseHoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(182)))), ((int)(((byte)(245)))));
            this.n_TextboxMauKhauDangNhap.LineThickness = 4;
            this.n_TextboxMauKhauDangNhap.Location = new System.Drawing.Point(327, 227);
            this.n_TextboxMauKhauDangNhap.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.n_TextboxMauKhauDangNhap.Name = "n_TextboxMauKhauDangNhap";
            this.n_TextboxMauKhauDangNhap.Size = new System.Drawing.Size(409, 34);
            this.n_TextboxMauKhauDangNhap.TabIndex = 15;
            this.n_TextboxMauKhauDangNhap.Text = "12345678";
            this.n_TextboxMauKhauDangNhap.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.n_TextboxMauKhauDangNhap.OnValueChanged += new System.EventHandler(this.n_TextboxMauKhauDangNhap_OnValueChanged);
            // 
            // bunifuCustomLabel4
            // 
            this.bunifuCustomLabel4.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.bunifuCustomLabel4.AutoSize = true;
            this.bunifuCustomLabel4.Font = new System.Drawing.Font("Segoe UI Light", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel4.Location = new System.Drawing.Point(132, 236);
            this.bunifuCustomLabel4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.bunifuCustomLabel4.Name = "bunifuCustomLabel4";
            this.bunifuCustomLabel4.Size = new System.Drawing.Size(89, 25);
            this.bunifuCustomLabel4.TabIndex = 14;
            this.bunifuCustomLabel4.Text = "Mật khẩu:";
            // 
            // n_TextboxTenDangNhap
            // 
            this.n_TextboxTenDangNhap.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.n_TextboxTenDangNhap.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.n_TextboxTenDangNhap.Font = new System.Drawing.Font("Segoe UI Light", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.n_TextboxTenDangNhap.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(182)))), ((int)(((byte)(245)))));
            this.n_TextboxTenDangNhap.HintForeColor = System.Drawing.Color.Empty;
            this.n_TextboxTenDangNhap.HintText = "";
            this.n_TextboxTenDangNhap.isPassword = false;
            this.n_TextboxTenDangNhap.LineFocusedColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(182)))), ((int)(((byte)(245)))));
            this.n_TextboxTenDangNhap.LineIdleColor = System.Drawing.Color.Gray;
            this.n_TextboxTenDangNhap.LineMouseHoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(182)))), ((int)(((byte)(245)))));
            this.n_TextboxTenDangNhap.LineThickness = 4;
            this.n_TextboxTenDangNhap.Location = new System.Drawing.Point(330, 152);
            this.n_TextboxTenDangNhap.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.n_TextboxTenDangNhap.Name = "n_TextboxTenDangNhap";
            this.n_TextboxTenDangNhap.Size = new System.Drawing.Size(406, 34);
            this.n_TextboxTenDangNhap.TabIndex = 13;
            this.n_TextboxTenDangNhap.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // bunifuCustomLabel3
            // 
            this.bunifuCustomLabel3.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.bunifuCustomLabel3.AutoSize = true;
            this.bunifuCustomLabel3.Font = new System.Drawing.Font("Segoe UI Light", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel3.Location = new System.Drawing.Point(132, 161);
            this.bunifuCustomLabel3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.bunifuCustomLabel3.Name = "bunifuCustomLabel3";
            this.bunifuCustomLabel3.Size = new System.Drawing.Size(134, 25);
            this.bunifuCustomLabel3.TabIndex = 12;
            this.bunifuCustomLabel3.Text = "Tên đăng nhập:";
            // 
            // bunifuCustomLabel5
            // 
            this.bunifuCustomLabel5.AutoSize = true;
            this.bunifuCustomLabel5.Font = new System.Drawing.Font("Segoe UI Light", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuCustomLabel5.Location = new System.Drawing.Point(132, 461);
            this.bunifuCustomLabel5.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.bunifuCustomLabel5.Name = "bunifuCustomLabel5";
            this.bunifuCustomLabel5.Size = new System.Drawing.Size(323, 25);
            this.bunifuCustomLabel5.TabIndex = 18;
            this.bunifuCustomLabel5.Text = "Nếu chưa có tài khoản, mời khách hàng";
            // 
            // n_ButtonDangKi
            // 
            this.n_ButtonDangKi.ActiveBorderThickness = 1;
            this.n_ButtonDangKi.ActiveCornerRadius = 20;
            this.n_ButtonDangKi.ActiveFillColor = System.Drawing.Color.White;
            this.n_ButtonDangKi.ActiveForecolor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(182)))), ((int)(((byte)(245)))));
            this.n_ButtonDangKi.ActiveLineColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(182)))), ((int)(((byte)(245)))));
            this.n_ButtonDangKi.BackColor = System.Drawing.Color.White;
            this.n_ButtonDangKi.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("n_ButtonDangKi.BackgroundImage")));
            this.n_ButtonDangKi.ButtonText = "Đăng kí";
            this.n_ButtonDangKi.Cursor = System.Windows.Forms.Cursors.Hand;
            this.n_ButtonDangKi.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.n_ButtonDangKi.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(182)))), ((int)(((byte)(245)))));
            this.n_ButtonDangKi.IdleBorderThickness = 1;
            this.n_ButtonDangKi.IdleCornerRadius = 20;
            this.n_ButtonDangKi.IdleFillColor = System.Drawing.Color.White;
            this.n_ButtonDangKi.IdleForecolor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(182)))), ((int)(((byte)(245)))));
            this.n_ButtonDangKi.IdleLineColor = System.Drawing.Color.White;
            this.n_ButtonDangKi.Location = new System.Drawing.Point(462, 453);
            this.n_ButtonDangKi.Margin = new System.Windows.Forms.Padding(5);
            this.n_ButtonDangKi.Name = "n_ButtonDangKi";
            this.n_ButtonDangKi.Size = new System.Drawing.Size(165, 45);
            this.n_ButtonDangKi.TabIndex = 17;
            this.n_ButtonDangKi.Tag = "";
            this.n_ButtonDangKi.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.n_ButtonDangKi.Click += new System.EventHandler(this.bunifuThinButton22_Click);
            // 
            // n_ButtonDangNhap
            // 
            this.n_ButtonDangNhap.ActiveBorderThickness = 1;
            this.n_ButtonDangNhap.ActiveCornerRadius = 20;
            this.n_ButtonDangNhap.ActiveFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(182)))), ((int)(((byte)(245)))));
            this.n_ButtonDangNhap.ActiveForecolor = System.Drawing.Color.White;
            this.n_ButtonDangNhap.ActiveLineColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(182)))), ((int)(((byte)(245)))));
            this.n_ButtonDangNhap.BackColor = System.Drawing.Color.White;
            this.n_ButtonDangNhap.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("n_ButtonDangNhap.BackgroundImage")));
            this.n_ButtonDangNhap.ButtonText = "Đăng nhập";
            this.n_ButtonDangNhap.Cursor = System.Windows.Forms.Cursors.Hand;
            this.n_ButtonDangNhap.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.n_ButtonDangNhap.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(182)))), ((int)(((byte)(245)))));
            this.n_ButtonDangNhap.IdleBorderThickness = 1;
            this.n_ButtonDangNhap.IdleCornerRadius = 20;
            this.n_ButtonDangNhap.IdleFillColor = System.Drawing.Color.White;
            this.n_ButtonDangNhap.IdleForecolor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(182)))), ((int)(((byte)(245)))));
            this.n_ButtonDangNhap.IdleLineColor = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(182)))), ((int)(((byte)(245)))));
            this.n_ButtonDangNhap.Location = new System.Drawing.Point(571, 319);
            this.n_ButtonDangNhap.Margin = new System.Windows.Forms.Padding(5);
            this.n_ButtonDangNhap.Name = "n_ButtonDangNhap";
            this.n_ButtonDangNhap.Size = new System.Drawing.Size(165, 45);
            this.n_ButtonDangNhap.TabIndex = 16;
            this.n_ButtonDangNhap.Tag = "";
            this.n_ButtonDangNhap.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.n_ButtonDangNhap.Click += new System.EventHandler(this.n_ButtonDangNhap_Click);
            // 
            // n_Status
            // 
            this.n_Status.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.n_Status.AutoSize = true;
            this.n_Status.Font = new System.Drawing.Font("Segoe UI Light", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.n_Status.Location = new System.Drawing.Point(218, 113);
            this.n_Status.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.n_Status.Name = "n_Status";
            this.n_Status.Size = new System.Drawing.Size(0, 25);
            this.n_Status.TabIndex = 20;
            // 
            // UCDangNhap
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.Controls.Add(this.n_Status);
            this.Controls.Add(this.bunifuCustomLabel5);
            this.Controls.Add(this.n_ButtonDangKi);
            this.Controls.Add(this.n_ButtonDangNhap);
            this.Controls.Add(this.n_TextboxMauKhauDangNhap);
            this.Controls.Add(this.bunifuCustomLabel4);
            this.Controls.Add(this.n_TextboxTenDangNhap);
            this.Controls.Add(this.bunifuCustomLabel3);
            this.Controls.Add(this.bunifuCustomLabel2);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "UCDangNhap";
            this.Size = new System.Drawing.Size(869, 503);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel2;
        private Bunifu.Framework.UI.BunifuMaterialTextbox n_TextboxMauKhauDangNhap;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel4;
        private Bunifu.Framework.UI.BunifuMaterialTextbox n_TextboxTenDangNhap;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel3;
        private Bunifu.Framework.UI.BunifuCustomLabel bunifuCustomLabel5;
        private Bunifu.Framework.UI.BunifuThinButton2 n_ButtonDangNhap;
        private Bunifu.Framework.UI.BunifuThinButton2 n_ButtonDangKi;
        private Bunifu.Framework.UI.BunifuCustomLabel n_Status;
    }
}
